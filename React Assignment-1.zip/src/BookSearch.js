import React, { useState } from 'react';
import './BookSearch.css'; // Import CSS file for styling

const BookSearch = () => {
  const [query, setQuery] = useState('');
  const [books, setBooks] = useState([]);
  const [error, setError] = useState(null);

  const handleChange = (event) => {
    setQuery(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (query.trim() === '') {
      setError('Please enter a book title');
      return;
    }

    // Fetch books from Google Books API
    fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch books');
        }
        return response.json();
      })
      .then(data => {
        if (data.items) {
          setBooks(data.items);
          setError(null);
        } else {
          setError('No books found');
          setBooks([]);
        }
      })
      .catch(error => {
        setError('Error fetching books');
        console.error(error);
      });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter book title"
          value={query}
          onChange={handleChange}
        />
        <button type="submit">Search</button>
      </form>
      {error && <p>{error}</p>}
      <div className="book-grid">
        {books.map(book => (
          <div className="book-item" key={book.id}>
            <div>
              <h3>{book.volumeInfo.title}</h3>
              {book.volumeInfo.authors && <p>Author: {book.volumeInfo.authors.join(', ')}</p>}
              {book.volumeInfo.imageLinks && <img src={book.volumeInfo.imageLinks.thumbnail} alt="Book Cover" />}
              {/* Render other book information as needed */}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookSearch;
