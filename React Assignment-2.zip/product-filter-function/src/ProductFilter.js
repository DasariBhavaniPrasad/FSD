import React, { useState } from 'react';

const ProductFilter = ({ products, onFilter }) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Extract unique company names from products
  const uniqueCompanies = [...new Set(products.map(product => product.company))];

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value.toLowerCase()); 
    const filteredProducts = products.filter(product => product.company.toLowerCase().includes(event.target.value.toLowerCase()));
    onFilter(filteredProducts);
  };

  const handleFilterByCompany = (company) => {
    const filteredProducts = products.filter(product => product.company === company);
    onFilter(filteredProducts);
  };

  const handleShowAll = () => {
    onFilter(products);
  };

  return (
    <div className="product-filter">
      <div className="search-container">
        <input type="text" value={searchTerm} onChange={handleSearchChange} placeholder="Search..." />
      </div>
      <h3 style={{position:"relative",left:"20px",top:"50px",fontSize:"18px"}}>Company</h3>
      <div className="button-container">
        <div>
          <button onClick={handleShowAll}>All</button>
        </div>
        {uniqueCompanies.map(company => (
          <div key={company}>
            <button onClick={() => handleFilterByCompany(company)}>{company}</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductFilter;
